const LANDING_PAGE_URL = '/';
const LOGIN_PAGE_URL = '/login';
const SIGNUP_PAGE_URL = '/signup';

const pageurl = {
  LANDING_PAGE_URL,
  LOGIN_PAGE_URL,
  SIGNUP_PAGE_URL,
};

export default pageurl;
