import React from 'react';
import SampleCss from './Sample.module.css'


const Sample = () => {
    return(

        <div className={SampleCss.sample}>

            <h1>Sample Page</h1>

        </div>
    )
}

export default Sample;